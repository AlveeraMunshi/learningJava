using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class Move2 : MonoBehaviour
{
    private Rigidbody body;
    private GameObject plane;
    private GameObject text;
    private Text display;
    // Start is called before the first frame update
    void Start()
    {
        body = GetComponent<Rigidbody>();
        plane = GameObject.Find("Plane");
        text = GameObject.Find("Text");
        display = text.transform.GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Vector3 v = new Vector3(0, 2, 0);
            body.AddForce(v * 200);

        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            Vector3 v = new Vector3(0, 0, -1);
            body.AddForce(v);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            Vector3 v = new Vector3(0, 0, 1);
            body.AddForce(v);
        }
    }
    private void FixedUpdate()
    {
        Vector3 cpos = body.position;
        Vector3 ppos = plane.transform.position;
        if (Vector3.Distance(cpos, ppos) > 100)
        {
            display.text = "You Lose";
        }
        else
        {
            display.text = "You Win";
        }
    }
}
