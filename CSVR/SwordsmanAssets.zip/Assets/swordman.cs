using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class swordman : MonoBehaviour
{
    // Start is called before the first frame update
    Animator ani;
    Vector2 dir;
    Rigidbody2D rb;
    int state;
    Boolean isGrounded = true;
    void Start()
    {
        ani = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        dir = Vector2.left * 0.01f;
    }
    enum States
    {
        idle,
        left,
        right
    }
    // Update is called once per frame
    void Update()
    {
        state = (int)States.idle;
        if (Input.GetKey(KeyCode.Space))
        {
            InvokeRepeating("Chop", 0.0f, 0.1f);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            state = (int)States.left;
            dir = Vector2.left * 0.01f;
            ani.SetBool("Move", true);
            Turn();
            Move();
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            state = (int)States.right;
            dir = Vector2.right * 0.01f;
            ani.SetBool("Move", true);
            Turn();
            Move();
        }
        else
        {
            ani.SetBool("Move", false);
        }
        if (isGrounded && Input.GetKey(KeyCode.UpArrow))
        {
            ani.SetTrigger("Jump");
            Jump();
        }
    }
    void Chop()
    {
        if (ani.GetBool("Chop") == false)
        {
            ani.SetBool("Chop", true);
        }
        else
        {
            ani.SetBool("Chop", false);
            CancelInvoke();
        }
    }
    void Move()
    {
        transform.Translate(dir);

    }
    void Jump()
    {
        rb.AddForce(Vector2.up * 700f);
        isGrounded = false;
    }
    void Turn()
    {
        if (state == (int)States.left)
            transform.localScale = new Vector3(1, 1, 1);
        if (state == (int)States.right)
            transform.localScale = new Vector3(-1, 1, 1);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "cube" && rb.velocity.y <= 0)
            isGrounded = true;
        if (!isGrounded)
        {
            ani.SetTrigger("Jump");
        }
        print(collision.gameObject);
    }
}
