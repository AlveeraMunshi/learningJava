﻿// See https://aka.ms/new-console-template for more information
namespace SampleNamespace
{
    public class List
    {
    }
}