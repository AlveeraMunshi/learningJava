using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour
{
    // Start is called before the first frame update
    Animator ani;
    Vector2 dir;
    Rigidbody2D rb;
    int state;
    Boolean isGrounded = true;
    GameObject swordman;
    void Start()
    {
        ani = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        dir = Vector2.left * 0.01f;
        swordman = GameObject.Find("sword_man");
    }
    enum States
    {
        idle,
        left,
        right
    }
    // Update is called once per frame
    void Update()
    {
        state = (int)States.idle;
        float deltax = Math.Abs(swordman.transform.position.x - transform.position.x);
        float deltay = Math.Abs(swordman.transform.position.y - transform.position.y);
        if (deltax >= 1.5f)
        {

            if (swordman.transform.position.x < transform.position.x)
            {
                state = (int)States.left; //sword on left
                dir = Vector2.left * 0.007f;
                ani.SetBool("Move", true);
            }
            else if (swordman.transform.position.x > transform.position.x)
            {
                state = (int)States.right; //sword on right
                dir = Vector2.right * 0.007f;
                ani.SetBool("Move", true);
            }
            Turn();
            Move();
        }
        else if (deltax <= 2f)
        {
            InvokeRepeating("Chop", 0.0f, 0.1f);
            ani.SetBool("Move", false);
        }
        else
        {
            ani.SetBool("Move", false);
        }
        if (deltay >= 1.5f && isGrounded)
        {
            if (swordman.transform.position.y > transform.position.y)
            {
                Jump();
            }
        }
    }
    void Chop()
    {
        if (ani.GetBool("Chop") == false)
        {
            ani.SetBool("Chop", true);
        }
        else
        {
            ani.SetBool("Chop", false);
            CancelInvoke();
        }
    }
    void Move()
    {
        transform.Translate(dir);

    }
    void Jump()
    {
        rb.AddForce(Vector2.up * 700f);
        isGrounded = false;
    }
    void Turn() //turns body
    {
        if (state == (int)States.left)
            transform.localScale = new Vector3(1, 1, 1);
        if (state == (int)States.right)
            transform.localScale = new Vector3(-1, 1, 1);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "cube")
            isGrounded = true;
        if (collision.gameObject.name.Equals("sword_man"))
        {
            InvokeRepeating("Chop", 0.0f, 0.1f);
        }
        print(collision.gameObject);
    }
}
